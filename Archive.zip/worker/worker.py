import json
import boto3
import sys
from textblob import TextBlob
import os
sys.path.append(os.path.join(os.getcwd(),'..'))
import watson_developer_cloud
import watson_developer_cloud.natural_language_understanding.features.v1 as features
from create import create_topic
from multiprocessing import Pool

alchemyapi = watson_developer_cloud.NaturalLanguageUnderstandingV1(version='2017-04-09',
                                                            username='30e12ed8-8326-4ffb-af41-9fc25c0cd5ff',
                                                            password='QYPu30Qsozcl')

sqs = boto3.resource('sqs')
queue = sqs.get_queue_by_name(QueueName='TwittMap')
topic = create_topic()


def worker(_):
    while True:
        for message in queue.receive_messages(MaxNumberOfMessages=10, WaitTimeSeconds=20):
            try:
                tweet = json.loads(message.body)
                res = TextBlob(tweet['text'])
                resp = res.sentiment.polarity
                if resp < 0:
                    sentiment = "negative"
                elif resp == 0:
                    sentiment = "neutral"
                else:
                    sentiment = "positive"
#                response = alchemyapi.analyze(text=tweet['text'],features=[features.Sentiment()])
#                response = alchemyapi.sentiment('text', tweet['text'])
                if sentiment != "":
                    tweet['sentiment'] = sentiment
#                    tweet['sentiment'] = response['docSentiment']['type']
                    encoded = json.dumps(tweet, ensure_ascii=False)
                    # Push to Amazon SNS
                    topic.publish(Message=encoded)
            finally:
                message.delete()


if __name__ == '__main__':
    pool = Pool(3)
    pool.map(worker, range(3))
